/*
	Alpha by HTML5 UP
	html5up.net | @ajlkn
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
*/

(function($) {

	var	$window = $(window),
		$body = $('body'),
		$header = $('#header'),
		$banner = $('#banner');

	// Breakpoints.
		breakpoints({
			wide:      ( '1281px',  '1680px' ),
			normal:    ( '981px',   '1280px' ),
			narrow:    ( '737px',   '980px'  ),
			narrower:  ( '737px',   '840px'  ),
			mobile:    ( '481px',   '736px'  ),
			mobilep:   ( null,      '480px'  )
		});

	// Play initial animations on page load.
		$window.on('load', function() {
			window.setTimeout(function() {
				$body.removeClass('is-preload');
			}, 100);
		});

	// Dropdowns.
		$('#nav > ul').dropotron({
			alignment: 'right'
		});

	// NavPanel.

		// Button.
			$(
				'<div id="navButton">' +
					'<a href="#navPanel" class="toggle"></a>' +
				'</div>'
			)
				.appendTo($body);

		// Panel.
			$(
				'<div id="navPanel">' +
					'<nav>' +
						$('#nav').navList() +
					'</nav>' +
				'</div>'
			)
				.appendTo($body)
				.panel({
					delay: 500,
					hideOnClick: true,
					hideOnSwipe: true,
					resetScroll: true,
					resetForms: true,
					side: 'left',
					target: $body,
					visibleClass: 'navPanel-visible'
				});

	// Header.
		if (!browser.mobile
		&&	$header.hasClass('alt')
		&&	$banner.length > 0) {

			$window.on('load', function() {

				$banner.scrollex({
					bottom:		$header.outerHeight(),
					terminate:	function() { $header.removeClass('alt'); },
					enter:		function() { $header.addClass('alt reveal'); },
					leave:		function() { $header.removeClass('alt'); }
				});

			});

		}
	
	
		

})(jQuery);
/*
$(document).ready(function() { 
		$('#favorite').on('click', function(e) { 
			var bookmarkURL = window.location.href; 
			var bookmarkTitle = document.title; 
			var triggerDefault = false; 
			
			if (window.sidebar && window.sidebar.addPanel) { 
				// Firefox version < 23 
				window.sidebar.addPanel(bookmarkTitle, bookmarkURL, ''); 
				} else if ((window.sidebar && (navigator.userAgent.toLowerCase().indexOf('firefox') > -1)) || (window.opera && window.print)) { 
					// Firefox version >= 23 and Opera Hotlist 
					var $this = $(this); 
					$this.attr('href', bookmarkURL); 
					$this.attr('title', bookmarkTitle); 
					$this.attr('rel', 'sidebar'); 
					$this.off(e); 
					triggerDefault = true; 
				} else if (window.external && ('AddFavorite' in window.external)) { 
					// IE Favorite 
					window.external.AddFavorite(bookmarkURL, bookmarkTitle); 
				} else { 
					// WebKit - Safari/Chrome 
					alert((navigator.userAgent.toLowerCase().indexOf('mac') != -1 ? 'Cmd' : 'Ctrl') + '+D 키를 눌러 즐겨찾기에 등록하실 수 있습니다.'); 
				} 
				
			return triggerDefault; 
		}); 
	});	
*/